-- Export-Fenster: Dialog im Stil von StaticPopup / MacroUI (3.3.5a).
-- Eigenen Build und Fremd-Inspect teilen sich den Frame, unterscheiden
-- sich ueber Titel, Hinweis und Statuszeile.

local BS = AscBuildschmiede

local FRAME_W, FRAME_H = 580, 460
local PAD = 18

local DIALOG_BACKDROP = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
}

-- Eingabeflaeche wie MacroFrameScrollFrame: dunkler Innenrahmen.
local INSET_BACKDROP = {
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
}

local frame

local function setPayload(f, payload)
    f.payload = payload or ""
    f.edit:SetText(f.payload)
    f.edit:SetFocus()
    f.edit:HighlightText()
    if f.scroll and f.scroll.SetVerticalScroll then
        f.scroll:SetVerticalScroll(0)
    end
end

local function applyMode(f, mode, meta)
    f.mode = mode
    meta = meta or {}

    if mode == "foreign" then
        f.title:SetText("Fremder Build")
        f.subtitle:SetText(string.format("|cffFFD100Inspect|r  %s", meta.name or "?"))
        f.hint:SetText(
            "Text ist markiert: |cffFFD100Strg+C|r, dann auf der Seite unter " ..
            "|cffFFD100VERGLEICH|r einfuegen.")
        f.refresh:SetText("Eigenen Build")
        f.info:SetTextColor(1, 0.82, 0)
    else
        f.title:SetText("Buildschmiede Export")
        f.subtitle:SetText("|cffAAAAAADein Charakter|r")
        f.hint:SetText(
            "Text ist markiert: |cffFFD100Strg+C|r, dann auf der Seite unter " ..
            "|cffFFD100EINFUEGEN|r ablegen.")
        f.refresh:SetText("Neu einlesen")
        f.info:SetTextColor(0.7, 0.7, 0.7)
    end
end

-- Zusatzinfos nur aus dem Export-Text lesen (kein Collect-Aufruf).
local function richnessFromPayload(payload)
    payload = payload or ""
    local bits = {}

    local specline = payload:match("\nSPEC|([^\n]+)") or payload:match("^SPEC|([^\n]+)")
    if specline then
        local sid, sname = specline:match("^([^|]+)|(.*)$")
        if not sid then sid = specline end
        sname = sname and sname:match("%S") and sname or nil
        if sname then
            bits[#bits + 1] = "Spec " .. sid .. " " .. sname
        else
            bits[#bits + 1] = "Spec " .. sid
        end
    end

    local lockline = payload:match("\nLOCK|([^\n]+)") or payload:match("^LOCK|([^\n]+)")
    if lockline and lockline ~= "" then
        local n = 0
        for _ in lockline:gmatch("[^;]+") do n = n + 1 end
        if n > 0 then bits[#bits + 1] = "LOCK " .. n end
    end

    local mode = payload:match("\nMODE|([^\n|]+)") or payload:match("^MODE|([^\n|]+)")
    if mode and mode ~= "" then
        bits[#bits + 1] = mode
    end

    local gearN = 0
    for line in payload:gmatch("[^\r\n]+") do
        if line:sub(1, 5) == "GEAR|" then gearN = gearN + 1 end
    end
    local ilvl = payload:match("\nILVL|([^\n]+)") or payload:match("^ILVL|([^\n]+)")
    if gearN > 0 or ilvl then
        if gearN > 0 and ilvl then
            bits[#bits + 1] = string.format("%d Items · iLvl %s", gearN, ilvl)
        elseif gearN > 0 then
            bits[#bits + 1] = gearN .. " Items"
        else
            bits[#bits + 1] = "iLvl " .. ilvl
        end
    end

    return bits
end

local function statusOwn(payload)
    local abi, tal = payload:match("COUNT|A:(%d+)|T:(%d+)")
    local char = payload:match("CHAR|([^|]+)")
    local path = payload:match("PATH|([^\n|]+)")
    local db = BS.DB()
    local qline = payload:match("QUALITY|([^\n]+)")
    local parts = {
        string.format("v%s", BS.VERSION),
        char,
        path and ("Path " .. path) or nil,
        string.format("%s ABI · %s TAL", abi or "?", tal or "?"),
    }
    local rich = richnessFromPayload(payload)
    for i = 1, #rich do parts[#parts + 1] = rich[i] end
    parts[#parts + 1] = "Gear:" .. (db.includeGear and "an" or "aus")
    parts[#parts + 1] = "Stats:" .. (db.includeStats and "an" or "aus")
    local out = {}
    for i = 1, #parts do
        if parts[i] then out[#out + 1] = parts[i] end
    end
    local s = table.concat(out, "  |  ")
    if qline then
        s = s .. "  |  " .. qline:gsub("|", " · ")
    end
    return s
end

local function statusForeign(payload)
    local name = payload:match("CHAR|([^|]+)")
    local level = payload:match("CHAR|[^|]+|(%d+)")
    local path = payload:match("PATH|([^\n|]+)")
    local abi, tal = payload:match("COUNT|A:(%d+)|T:(%d+)")
    local who = name or "?"
    if level then who = who .. " L" .. level end
    local parts = {
        "Inspect",
        who,
        path and ("Path " .. path) or nil,
        string.format("%s ABI · %s TAL", abi or "?", tal or "?"),
    }
    local rich = richnessFromPayload(payload)
    for i = 1, #rich do parts[#parts + 1] = rich[i] end
    parts[#parts + 1] = "→ VERGLEICH auf der Seite"
    local out = {}
    for i = 1, #parts do
        if parts[i] then out[#out + 1] = parts[i] end
    end
    return table.concat(out, "  |  ")
end

local function makeFrame()
    local f = CreateFrame("Frame", "AscBuildschmiedeFrame", UIParent)
    f:SetWidth(FRAME_W)
    f:SetHeight(FRAME_H)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetToplevel(true)
    f:SetBackdrop(DIALOG_BACKDROP)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:Hide()
    tinsert(UISpecialFrames, "AscBuildschmiedeFrame")

    -- Titelbanner wie bei vielen 3.3.5a-Dialogen (StaticPopup-Familie).
    local header = f:CreateTexture(nil, "ARTWORK")
    header:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
    header:SetWidth(320)
    header:SetHeight(64)
    header:SetPoint("TOP", 0, 12)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", header, "TOP", 0, -14)
    title:SetText("Buildschmiede Export")
    f.title = title

    local closeX = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeX:SetPoint("TOPRIGHT", -4, -4)
    closeX:SetScript("OnClick", function() f:Hide() end)

    local subtitle = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    subtitle:SetPoint("TOPLEFT", PAD + 4, -36)
    subtitle:SetPoint("TOPRIGHT", -(PAD + 28), -36)
    subtitle:SetJustifyH("LEFT")
    f.subtitle = subtitle

    local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", PAD + 4, -54)
    hint:SetPoint("TOPRIGHT", -(PAD + 4), -54)
    hint:SetJustifyH("LEFT")
    hint:SetHeight(28)
    f.hint = hint

    local urlLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    urlLabel:SetPoint("TOPLEFT", PAD + 4, -86)
    urlLabel:SetText("Seite:")

    local url = CreateFrame("EditBox", "AscBuildschmiedeURL", f, "InputBoxTemplate")
    url:SetAutoFocus(false)
    url:SetHeight(20)
    url:SetPoint("LEFT", urlLabel, "RIGHT", 8, 0)
    url:SetPoint("RIGHT", -(PAD + 8), 0)
    url:SetText(BS.SITE)
    url:SetCursorPosition(0)
    url:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    url:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    url:SetScript("OnEditFocusLost", function(self)
        self:SetText(BS.SITE)
        self:SetCursorPosition(0)
    end)
    url:SetScript("OnTextChanged", function(self, user)
        if user and self:GetText() ~= BS.SITE then
            self:SetText(BS.SITE)
            self:HighlightText()
        end
    end)
    f.url = url

    local inset = CreateFrame("Frame", nil, f)
    inset:SetPoint("TOPLEFT", PAD, -112)
    inset:SetPoint("BOTTOMRIGHT", -(PAD + 8), 72)
    inset:SetBackdrop(INSET_BACKDROP)
    inset:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
    inset:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    f.inset = inset

    local scroll = CreateFrame("ScrollFrame", "AscBuildschmiedeScroll", inset,
        "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 6, -6)
    scroll:SetPoint("BOTTOMRIGHT", -28, 6)
    f.scroll = scroll

    local edit = CreateFrame("EditBox", "AscBuildschmiedeEdit", scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject(GameFontHighlightSmall)
    edit:SetWidth(FRAME_W - PAD * 2 - 48)
    edit:SetMaxLetters(0)
    edit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        f:Hide()
    end)
    -- Nur Anzeige: User-Eingaben zuruecksetzen, Parser-Text bleibt exakt.
    edit:SetScript("OnTextChanged", function(self, user)
        if user then
            self:SetText(f.payload or "")
            self:HighlightText()
        end
    end)
    scroll:SetScrollChild(edit)
    f.edit = edit

    local info = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    info:SetPoint("BOTTOMLEFT", PAD + 4, 48)
    info:SetPoint("BOTTOMRIGHT", -(PAD + 4), 48)
    info:SetJustifyH("LEFT")
    info:SetHeight(18)
    f.info = info

    local copy = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    copy:SetWidth(140)
    copy:SetHeight(24)
    copy:SetPoint("BOTTOMLEFT", PAD, 18)
    copy:SetText("Alles markieren")
    copy:SetScript("OnClick", function()
        edit:SetFocus()
        edit:HighlightText()
    end)

    local refresh = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    refresh:SetWidth(120)
    refresh:SetHeight(24)
    refresh:SetPoint("LEFT", copy, "RIGHT", 8, 0)
    refresh:SetText("Neu einlesen")
    refresh:SetScript("OnClick", function()
        -- Fremdmodus: wechselt auf den eigenen Export.
        BS.Refresh()
    end)
    f.refresh = refresh

    local close = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    close:SetWidth(100)
    close:SetHeight(24)
    close:SetPoint("BOTTOMRIGHT", -PAD, 18)
    close:SetText("Schliessen")
    close:SetScript("OnClick", function() f:Hide() end)

    applyMode(f, "own")
    return f
end

function BS.Refresh()
    if not frame then return end
    local payload = BS.BuildExport()
    applyMode(frame, "own")
    setPayload(frame, payload)
    frame.info:SetText(statusOwn(payload))
end

-- Fremder Build: gleiches Fenster, eigener Modus — Refresh ersetzt ihn
-- erst, wenn der Spieler "Eigenen Build" waehlt.
function BS.ShowForeign(payload)
    if not frame then frame = makeFrame() end
    frame:Show()
    local name = payload and payload:match("CHAR|([^|]+)")
    applyMode(frame, "foreign", { name = name })
    setPayload(frame, payload)
    frame.info:SetText(statusForeign(payload or ""))
end

function BS.Toggle()
    if not frame then frame = makeFrame() end
    if frame:IsShown() then
        frame:Hide()
        return
    end
    frame:Show()
    BS.Refresh()
end
